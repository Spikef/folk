将install文件夹(包括install文件夹本身)上传到网站根目录
然后访问[http://你的网站域名/install]进行安装

Upload the install folder(include install) to the root dir of your website
Open browser to visit [http://yourdomain/install] to install Folk