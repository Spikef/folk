将install文件夹(包括install文件夹本身)上传到网站根目录
然后在命令行执行[node install]进行安装

Upload the install folder(include install) to the root dir of your website
Open terminal or cmd to run [node install] to install Folk