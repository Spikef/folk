﻿(function(){
	var article = {
		activeTab: function() {
			if (localStorage) {
				var frame = $('#article-body').find('ul:first');

				var tabId = localStorage.getItem('article_post_active_tab');
				if (tabId) {
					frame.find('a[href="' + tabId + '"]').trigger('click');
				}

				frame.find('a[data-toggle="tab"]').on('click', function() {
					localStorage.setItem('article_post_active_tab', $(this).attr('href'));
				});
			}
		},
		fullScreen: function() {
			var that = this;
			var frame = $('#article-body');
			$('#full-screen-button').on('click', function() {
				if (that.fullscreen) {
					frame.removeClass('full-screen');
				} else {
					frame.addClass('full-screen');
				}
				that.fullscreen = !that.fullscreen;
			});
		},
		bindSelect: function() {
			var frame = $('#article-body');

			frame.find('#art-tags').select2({tags: true});
			frame.find('#art-cate').select2({minimumResultsForSearch: Infinity, language: blog.language});
			frame.find('#art-type').select2({minimumResultsForSearch: Infinity, language: blog.language});
			frame.find('.select2').css({width: '', display: 'block'});
		},
		onTitleChange: function() {
			$('#art-title').bind('input propertychange', function(e) {
				var title = this.value;
				var alias = PinYin(title, '-')
								.replace(/[A-Z](?=[a-z])/g, '-$&')
								.replace(/[^\w]+/g, '-')
								.replace(/(^\-|\-$)/gm, '')
								.toLowerCase();

				$('#art-alias').val(alias);
			});
		},
		onSelectChange: function() {
			$('#art-cate').on('select2:select', function(e) {
				var id = e.params.data.element;
				var text = $(id).attr('data-desc');
				$('#art-cate-desc').text(text);
			});

			$('#art-type').on('select2:select', function(e) {
				var id = e.params.data.element;
				var text = $(id).attr('data-desc');
				$('#art-type-desc').text(text);
			});
		},
		onPostSuccess: function() {
			//$('#article-form').on('form.ajaxSuccess', function(e, result) {
			//	var id = result.art_id;
			//	var url = modules.url.setUrl('stage', 'article', {id: id});
			//	setTimeout(function() {
			//		window.location.href = url;
			//	}, 200);
			//});
		},

		init: function() {
			this.activeTab();
			this.fullScreen();
			this.bindSelect();
			this.onTitleChange();
			this.onSelectChange();
			this.onPostSuccess();
		}
	};

	$(document).ready(function(){
		article.init();
	});
}());