$(document).ready(function(){
    $('#wm-opacity, #wm-position').select2({
        minimumResultsForSearch: Infinity,
        language: blog.language
    });
});