(function(){
    var options = {
        "gfm": true,
        "tables": true,
        "breaks": false,
        "pedantic": false,
        "sanitize": false,
        "smartLists": true,
        "smartypants": false,
        "langPrefix": "language-",
        "headerPrefix": "head-",
        "xhtml": false
    };

    var toolbar = $('#editor-toolbar');
    var textBox = $('#editor-section').find('textarea:first');
    var TextBox = new Selection(textBox);

    var stack = new Undo.Stack(500);
    var command = Undo.Command.extend({
        constructor: function(textarea, oldValue, newValue, oldCursor, newCursor) {
            this.textarea = textarea;
            this.oldValue = oldValue;
            this.newValue = newValue;
            this.oldCursor = oldCursor;
            this.newCursor = newCursor;
        },
        execute: function() {
        },
        undo: function() {
            this.textarea.val(this.oldValue);
            TextBox.cursor(this.oldCursor);
            textBox.trigger('undo');
            textBox.focus();
        },
        redo: function() {
            this.textarea.val(this.newValue);
            TextBox.cursor(this.newCursor);
            textBox.trigger('redo');
            textBox.focus();
        }
    });

    var editor = {
        bold: function() {
            var text = TextBox.text();
            var outs = TextBox.surround(2);
            var cursor;
            if (/^[*_]{2}/.test(text) && /[*_]{2}$/.test(text)) {
                TextBox.text(text.replace(/^[*_]{2}|[*_]{2}$/g, ''));
            } else if (outs[0] === '**' && outs[1] === '**') {
                cursor = TextBox.cursor();
                cursor[0] = cursor[0] - 2;
                cursor[1] = cursor[1] + 2;
                if (text) {
                    TextBox.cursor(cursor);
                    TextBox.text(text);
                } else {
                    TextBox.deleteRange(cursor);
                }
            } else {
                TextBox.append('**').prepend('**');
                if (!text) {
                    cursor = TextBox.cursor();
                    cursor[0] = cursor[0] + 2;
                    cursor[1] = cursor[1] - 2;
                    TextBox.cursor(cursor);
                }
            }
        },
        italic: function() {
            var text = TextBox.text();
            var outs = TextBox.surround(1);
            var cursor;
            if (/^[*_]/.test(text) && /[*_]$/.test(text)) {
                TextBox.text(text.replace(/^[*_]|[*_]$/g, ''));
            } else if (outs[0] === '*' && outs[1] === '*') {
                cursor = TextBox.cursor();
                cursor[0] = cursor[0] - 1;
                cursor[1] = cursor[1] + 1;
                if (text) {
                    TextBox.cursor(cursor);
                    TextBox.text(text);
                } else {
                    TextBox.deleteRange(cursor);
                }
            } else {
                TextBox.append('*').prepend('*');
                if (!text) {
                    cursor = TextBox.cursor();
                    cursor[0] = cursor[0] + 1;
                    cursor[1] = cursor[1] - 1;
                    TextBox.cursor(cursor);
                }
            }
        },
        h1: function() {
            this.header(1);
        },
        h2: function() {
            this.header(2);
        },
        h3: function() {
            this.header(3);
        },
        h4: function() {
            this.header(4);
        },
        h5: function() {
            this.header(5);
        },
        h6: function() {
            this.header(6);
        },
        header: function(count) {
            var flag = '#'.repeat(count) + ' ';
            var lines = TextBox.lines();
            textBox.trigger('cursor');
            TextBox.insertText(flag, lines.start);
        },
        ul: function() {
            var lines = TextBox.lines();
            if (lines.text) {
                var text = lines.text.replace(/\n/g, '\n+ ');
                textBox.trigger('cursor');
                TextBox.cursor(lines.start, lines.end);
                TextBox.text(text);
                TextBox.insertText('+ ', lines.start);
                TextBox.caret(lines.end + 2);
            } else {
                textBox.trigger('cursor');
                TextBox.insertText('+ ', lines.start);
                TextBox.caret(lines.end + 2);
            }
        },
        ol: function() {
            var lines = TextBox.lines();
            if (lines.text) {
                var index = 1;
                var text = lines.text.replace(/\n/g, function($0) {
                    index++;
                    return $0 + index + '. ';
                });
                textBox.trigger('cursor');
                TextBox.cursor(lines.start, lines.end);
                TextBox.text(text);
                TextBox.insertText('1. ', lines.start);
                TextBox.caret(lines.end + 3);
            } else {
                textBox.trigger('cursor');
                TextBox.insertText('1. ', lines.start);
                TextBox.caret(lines.end + 3);
            }
        },
        quote: function() {
            var lines = TextBox.lines();
            if (lines.text) {
                var text = lines.text.replace(/\n/g, '  \n> ');
                textBox.trigger('cursor');
                TextBox.cursor(lines.start, lines.end);
                TextBox.text(text);
                TextBox.insertText('> ', lines.start);
                TextBox.caret(lines.end + 2);
            } else {
                textBox.trigger('cursor');
                TextBox.insertText('> ', lines.start);
                TextBox.caret(lines.end + 2);
            }
        },
        code: function() {
            var text = TextBox.text();
            var lines = TextBox.lines();
            if (text) {
                if (/\n/.test(text)) {
                    textBox.trigger('cursor');
                    TextBox.cursor(lines.start, lines.end);
                    TextBox.append('\n```').prepend('```\n');
                } else {
                    TextBox.append('`').prepend('`');
                }
            } else {
                textBox.trigger('cursor');
                TextBox.insertText('``', lines.cursor[0]);
                TextBox.caret(lines.cursor[0] + 1);
            }
        },
        line: function() {
            var lines = TextBox.lines();
            if (lines.text) {
                textBox.trigger('cursor');
                TextBox.insertText('\n\n----------\n\n', lines.cursor[0]);
                TextBox.caret(lines.cursor[1] + 14);
            } else {
                textBox.trigger('cursor');
                TextBox.insertText('\n----------\n', lines.cursor[0]);
                TextBox.caret(lines.end + 12);
            }
        },
        link: function(btn, data) {
            if (typeof data === 'undefined') {
                $('#modal-link').modal({backdrop: 'static'});
            } else {
                data.text = data.text || data.href;
                data.title = data.title ? ' "' + data.title + '"' : '';
                var text = '[' + data.text + '](' + data.href + data.title + ')';
                var caret = TextBox.caret();
                textBox.trigger('cursor');
                TextBox.insertText(text, caret);
                TextBox.caret(caret + text.length);
                textBox.focus();
            }
        },
        image: function(btn, data) {
            if (typeof data === 'undefined' && FileReader) {
                $('#modal-image').modal({backdrop: 'static'});
            } else {
                var text = '![' + data.title + '](' + data.href + ')';
                var caret = TextBox.caret();
                textBox.trigger('cursor');
                TextBox.insertText(text, caret);
                TextBox.caret(caret + text.length);
                textBox.focus();
            }
        },
        attach: function(btn, data) {
            if (typeof data === 'undefined' && FileReader) {
                $('#modal-attach').modal({backdrop: 'static'});
            } else {
                data.text = data.text || data.href;
                data.title = data.title ? ' "' + data.title + '"' : '';
                var text = '[' + data.text + '](' + data.href + data.title + ')';
                var caret = TextBox.caret();
                textBox.trigger('cursor');
                TextBox.insertText(text, caret);
                TextBox.caret(caret + text.length);
                textBox.focus();
            }
        },
        file: function(btn, data) {
            if (typeof data === 'undefined' && FileReader) {
                $('#modal-file').modal({backdrop: 'static'});
            } else {
                if (data.mode == 1) {
                    textBox.trigger('cursor');
                    TextBox.cursor(0, textBox.val().length);
                    TextBox.text(data.text);
                } else {
                    var caret = TextBox.caret();
                    textBox.trigger('cursor');
                    TextBox.insertText(data.text, caret);
                }
            }
        },
        undo: function() {
            stack.canUndo() && stack.undo();
        },
        redo: function() {
            stack.canRedo() && stack.redo();
        },
        preview: function(btn) {
            var SECTION = $('#editor-section');
            var PREVIEW = $('#editor-preview');

            if (!this.preview_flag) {
                var content = SECTION.find('textarea').val();
                var preview = marked(content, options);
                PREVIEW.html(preview);

                SECTION.slideToggle(400);
                PREVIEW.slideToggle(400);

                PREVIEW.find('code').each(function() {
                    Prism.highlightElement($(this)[0]);
                });

                btn.html('<i class="fa fa-eye"></i>');
            } else {
                SECTION.slideToggle(400);
                PREVIEW.slideToggle(400);

                btn.html('<i class="fa fa-eye-slash"></i>');

                textBox.focus();
            }

            this.preview_flag = !this.preview_flag;
        },
        initToolbar: function() {
            var that = this;
            $('#editor-toolbar').find('.btn').on('click', function() {
                var method = $(this).attr('data-method');
                that[method] && that[method].call(that, $(this));
            });
        },
        onAutoSave: function() {
            var that = this;
            var text = textBox.val() || localStorage.getItem('article_post_auto_save_local') || '';
            if (text) textBox.val(text);
            this.oldContent = text;
            this.oldCursor = TextBox.cursor();

            textBox.bind('input undo redo propertychange', function(e) {
                clearTimeout(that.auto_save_timer);
                var content = this.value;
                that.auto_save_timer = setTimeout(function() {
                    localStorage.setItem('article_post_auto_save_local', content);
                }, 1000);

                if (e.type === 'undo' || e.type === 'redo') {
                    that.oldContent = content;
                } else {
                    clearTimeout(that.undo_redo_timer);
                    that.undo_redo_timer = setTimeout(function() {
                        var newValue = content;
                        var oldValue = that.oldContent;
                        var newCursor = TextBox.cursor();
                        var oldCursor = that.oldCursor;
                        if (newValue != oldValue) {
                            stack.execute(new command(textBox, oldValue, newValue, oldCursor, newCursor));
                            that.oldContent = newValue;
                            that.oldCursor = TextBox.cursor();
                        }
                    }, 200);
                }
            });
        },
        onPostSuccess: function() {
            $('#article-form').on('form.ajaxSuccess', function() {
                localStorage && localStorage.removeItem('article_post_auto_save_local');
            });
        },
        initCursor: function() {
            var that = this;
            textBox.bind('mouseup cursor', function() {
                that.oldCursor = TextBox.cursor();
            });
        },
        initUndoRedo: function() {
            var undo = toolbar.find('.btn[data-method="undo"]');
            var redo = toolbar.find('.btn[data-method="redo"]');
            stack.changed = function() {
                if (stack.canUndo()) {
                    undo.removeClass('disabled');
                } else {
                    undo.addClass('disabled');
                }
                if (stack.canRedo()) {
                    redo.removeClass('disabled');
                } else {
                    redo.addClass('disabled');
                }
            };

            textBox.keydown(function(event) {
                if (!event.metaKey || event.keyCode != 90) {
                    return;
                }
                event.preventDefault();
                if (event.shiftKey) {
                    stack.canRedo() && stack.redo()
                } else {
                    stack.canUndo() && stack.undo();
                }
            });
        },
        initModals: function() {
            var that = this;
            $('#modal-link, #modal-image, #modal-file, #modal-attach').on('hidden.bs.modal', function () {
                textBox.focus();
            });

            $('#insert-link').on('click', function() {
                var links = {
                    href: $('#link-href').val(),
                    text: $('#link-text').val(),
                    title: $('#link-title').val()
                };

                $('#modal-link').modal('hide');

                if (links.href) that.link($(this), links);
            });

            $('#insert-attach').on('click', function() {
                var attach = {
                    href: $('#attach-href').val(),
                    text: $('#attach-text').val(),
                    title: $('#attach-title').val()
                };

                $('#modal-attach').modal('hide');

                if (attach.href) that.attach($(this), attach);
            });

            $('#insert-file').on('click', function() {
                var modal_file = $('#modal-file');
                var mode = $('input:radio[name="appendMarkdown"]:checked').val();
                var file = that.files[0];
                var fr = new FileReader();
                fr.onloadend = function(e) {
                    modal_file.modal('hide');
                    modal_file.find('input[type=file]').val('');

                    var text = e.target.result;
                    if (text) {
                        that.file($(this), {text: text, mode: mode});
                    }
                };
                fr.readAsText(file);
            });

            $('#insert-image').on('click', function() {
                var image = {
                    href: $('#image-href').val(),
                    title: $('#image-title').val()
                };

                $('#modal-image').modal('hide');

                if (image.href) that.image($(this), image);
            });
        },
        initFileInput: function() {
            var that = this;
            var fileInput = $('input[type=file]');
            fileInput.bootstrapFileInput();
            fileInput.on('change', function() {
                if (this.files && this.files[0] && /^text/.test(this.files[0].type)) {
                    that.files = this.files;
                }
            });
        },
        initAttachment: function() {
            var content = null, code = null;
            // 浏览并选择附件
            $('#file-attach-select').on('change', function() {
                if (this.files && this.files[0]) {
                    var file = this.files[0];
                    var name = file.name;

                    var bufferReader = new FileReader();
                    bufferReader.onload = function(e) {
                        code = crc32(e.target.result);
                    };
                    bufferReader.readAsArrayBuffer(file);

                    var dataUrlReader = new FileReader();
                    dataUrlReader.onload = function(e) {
                        content = e.target.result;
                    };
                    dataUrlReader.readAsDataURL(file);

                    $('#attach-filename').text(name);
                }

                $(this).val('');
            });

            // 上传附件
            var uploading = false;
            $('#file-attach-upload').on('click', function() {
                var filename = $('#attach-filename').text();
                if (uploading || !filename || !code || !content || content.length<20) return;

                var match;
                match = content.match(/base64,([A-Za-z0-9+/=]+)$/);
                if (!match || !match[1]) return;
                var data = match[1];
                match = filename.match(/\.(\w+)$/);
                if (!match || !match[1]) return;
                var ext = match[1];

                uploading = true;

                var that = $(this);
                that.addClass('loading');

                var check = modules.url.setUrl('api', 'upload', { m: 'check_file_exists' });
                var upload = modules.url.setUrl('api', 'upload', { m: 'attach' });

                $.post(check, {
                    code: code
                }, function(result){
                    code = null;
                    if ( result.success ){
                        toastr.success(result.message);
                        $('#attach-href').val(result.data);
                        content = null;
                        $('#attach-filename').text('');
                        that.removeClass('loading');
                        uploading = false;
                    }else{
                        $.post(upload, {
                            ext: ext,
                            data: data
                        }, function(result){
                            if ( result.success ){
                                toastr.success(result.message);
                                $('#attach-href').val(result.data);
                                content = null;
                                $('#attach-filename').text('');
                            }
                            that.removeClass('loading');
                            uploading = false;
                        }, 'json');
                    }
                }, 'json');

            });
        },
        init: function() {
            this.initAttachment();
            this.initFileInput();
            this.initUndoRedo();
            this.initToolbar();
            this.initCursor();
            this.initModals();
            this.onAutoSave();
            this.onPostSuccess();
        }
    };

    $(document).ready(function() {
        if (localStorage) editor.init();
    });

    // repeat poly fill
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/repeat
    if (!String.prototype.repeat) {
        String.prototype.repeat = function(count) {
            'use strict';
            if (this == null) {
                throw new TypeError('can\'t convert ' + this + ' to object');
            }
            var str = '' + this;
            count = +count;
            if (count != count) {
                count = 0;
            }
            if (count < 0) {
                throw new RangeError('repeat count must be non-negative');
            }
            if (count == Infinity) {
                throw new RangeError('repeat count must be less than infinity');
            }
            count = Math.floor(count);
            if (str.length == 0 || count == 0) {
                return '';
            }
            // Ensuring count is a 31-bit integer allows us to heavily optimize the
            // main part. But anyway, most current (August 2014) browsers can't handle
            // strings 1 << 28 chars or longer, so:
            if (str.length * count >= 1 << 28) {
                throw new RangeError('repeat count must not overflow maximum string size');
            }
            var rpt = '';
            for (;;) {
                if ((count & 1) == 1) {
                    rpt += str;
                }
                count >>>= 1;
                if (count == 0) {
                    break;
                }
                str += str;
            }
            // Could we try:
            // return Array(count + 1).join(this);
            return rpt;
        }
    }
}());