(function(){
    var code = null;

    // 浏览并选择图片
    $('#file-image-select').on('change', function() {
        if (this.files && this.files[0] && /^image/.test(this.files[0].type)) {
            var file = this.files[0];
            preview(file);

            var reader = new FileReader();
            reader.onload = function(e) {
                code = crc32(e.target.result);
            };
            reader.readAsArrayBuffer(file);
        }

        $(this).val('');
    });

    // 上传图片
    var uploading = false;
    $('#file-image-upload').on('click', function() {
        var src = $('#image-ready').attr('src');
        if (uploading || !src || src.length<20 || !code) return;

        var match = src.match(/data:image\/(\w+);base64,([A-Za-z0-9+/=]+)$/);
        if (!match) return;
        var ext = match[1], data = match[2];

        uploading = true;

        var that = $(this);
        that.addClass('loading');

        var check = modules.url.setUrl('api', 'upload', { m: 'check_file_exists' });
        var upload = modules.url.setUrl('api', 'upload', { m: 'image' });

        $.post(check, {
            code: code
        }, function(result){
            code = null;
            if ( result.success ){
                toastr.success(result.message);
                $('#image-href').val(result.data);
                that.removeClass('loading');
                uploading = false;
                setTimeout(function() {
                    $('a[href="#image-select"]').trigger('click');
                }, 100);
            }else{
                $.post(upload, {
                    ext: ext,
                    data: data
                }, function(result){
                    if ( result.success ){
                        toastr.success(result.message);
                        $('#image-href').val(result.data);
                        setTimeout(function() {
                            $('a[href="#image-select"]').trigger('click');
                        }, 100);
                    }
                    that.removeClass('loading');
                    uploading = false;
                }, 'json');
            }
        }, 'json');
    });

    // 从剪贴板获取图片, Chrome Only
    $('.image-area').on('paste', function(event) {
        var e = event.originalEvent;

        if (e && e.clipboardData && e.clipboardData.items[0].type.indexOf('image') > -1) {
            var file = e.clipboardData.items[0].getAsFile();
            preview(file);
        }
    });

    // 预览图片
    function preview(file, callback) {
        var reader = new FileReader(), html;
        reader.onload = function(e) {
            html = '<img src="'+ e.target.result +'" id="image-ready" />';
            $('#image-upload').find('.image-area').html(html);
            if (typeof callback === 'function') callback($('#image-ready'));
        };
        reader.readAsDataURL(file);
    }
}());