(function(){
    var code = null;
    var image = null;
    var water = editor.watermark;

    // 图片处理回调方法
    var callback = function(img){
        var bufferReader = new FileReader();
        bufferReader.onload = function(e) {
            code = crc32(e.target.result);
        };
        bufferReader.readAsArrayBuffer(img);

        var dataUrlReader = new FileReader();
        dataUrlReader.onload = function(e) {
            var html = '<img src="'+ e.target.result +'" id="image-ready" />';
            $('#image-upload').find('.image-area').html(html);
        };
        dataUrlReader.readAsDataURL(img);

        watermark.destroy();
    };

    // 浏览并选择图片
    $('#file-image-select').on('change', function() {
        if (this.files && this.files[0] && /^image/.test(this.files[0].type)) {
            image = this.files[0];

            if (water.auto) {
                if (water.type === 'image') {
                    watermark_image(image, callback);
                }else{
                    watermark_text(image, callback);
                }
            }else{
                preview(image);
            }
        }

        $(this).val('');
    });

    // 从剪贴板获取图片, Chrome Only
    $('.image-area').on('paste', function(event) {
        var e = event.originalEvent;

        if (e && e.clipboardData && e.clipboardData.items[0].type.indexOf('image') > -1) {
            image = e.clipboardData.items[0].getAsFile();

            if (water.auto) {
                if (water.type === 'image') {
                    watermark_image(image, callback);
                }else{
                    watermark_text(image, callback);
                }
            }else{
                preview(image);
            }
        }
    });

    // 点击水印按钮
    $('#append-watermark').on('click', function() {
        if (!image) return;

        if (water.type === 'image') {
            watermark_image(image, callback);
        }else{
            watermark_text(image, callback);
        }

        $(this).addClass('hide');
        $('#cancel-watermark').removeClass('hide');
    });

    $('#cancel-watermark').on('click', function() {
        if (!image) return;

        preview(image);

        $(this).addClass('hide');
        $('#append-watermark').removeClass('hide');
    });

    // 预览图片
    function preview(file) {
        var reader = new FileReader(), html;
        reader.onload = function(e) {
            html = '<img src="'+ e.target.result +'" id="image-ready" />';
            $('#image-upload').find('.image-area').html(html);
        };
        reader.readAsDataURL(file);
    }

    // 图片水印, 返回dataURL
    function watermark_image(image, callback) {
        watermark([image, water.image.content])
            .blob(watermark.image[water.image.position](water.image.opacity))
            .then(function (img) {
                callback(img);
            });
    }

    // 文字水印
    function watermark_text(image, callback) {
        watermark([image, water.image.content])
            .blob(watermark.text[water.text.position](water.text.content, water.text.font, water.text.color, water.text.opacity))
            .then(function (img) {
                callback(img);
            });
    }

    // 上传图片
    var uploading = false;
    $('#file-image-upload').on('click', function() {
        var src = $('#image-ready').attr('src');
        if (uploading || !src || src.length<20 || !code) return;

        var match = src.match(/data:image\/(\w+);base64,([A-Za-z0-9+/=]+)$/);
        if (!match) return;
        var ext = match[1], data = match[2];

        uploading = true;

        var that = $(this);
        that.addClass('loading');

        var check = modules.url.setUrl('api', 'upload', { m: 'check_file_exists' });
        var upload = modules.url.setUrl('api', 'upload', { m: 'image' });

        $.post(check, {
            code: code
        }, function(result){
            code = null;
            if ( result.success ){
                toastr.success(result.message);
                $('#image-href').val(result.data);
                that.removeClass('loading');
                uploading = false;
                setTimeout(function() {
                    $('a[href="#image-select"]').trigger('click');
                }, 100);
            }else{
                $.post(upload, {
                    ext: ext,
                    data: data
                }, function(result){
                    if ( result.success ){
                        toastr.success(result.message);
                        $('#image-href').val(result.data);
                        setTimeout(function() {
                            $('a[href="#image-select"]').trigger('click');
                        }, 100);
                    }
                    that.removeClass('loading');
                    uploading = false;
                }, 'json');
            }
        }, 'json');
    });
}());